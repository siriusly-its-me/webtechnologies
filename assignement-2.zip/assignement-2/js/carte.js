// Fonction pour initialiser la carte
function initMap() {
    // Spécifiez le point central de la carte (par exemple, une latitude et une longitude)
    const center = { lat: 48.8566, lng: 2.3522 }; // Paris
    
    // Créez une carte centrée sur le point spécifié
    const map = new google.maps.Map(document.getElementById('map'), {
        center: center,
        zoom: 12
    });

    // Exemple d'adresse pour placer des épingles sur la carte
    const addresses = [
        'Paris, France',
        'London, UK',
        'Berlin, Germany'
        // Ajoutez d'autres adresses ici
    ];

    // Fonction pour géocoder une adresse et placer une épingle sur la carte
    function geocodeAndPlaceMarker(address) {
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: address }, (results, status) => {
            if (status === 'OK') {
                const location = results[0].geometry.location;
                // Créez une épingle (marqueur) et placez-la sur la carte
                new google.maps.Marker({
                    position: location,
                    map: map
                });
            } else {
                console.log('Geocode was not successful for the following reason: ' + status);
            }
        });
    }

    // Placez des épingles pour chaque adresse
    addresses.forEach(address => {
        geocodeAndPlaceMarker(address);
    });
}

// Appelez `initMap` lorsque le document est chargé
document.addEventListener('DOMContentLoaded', initMap);
